<?php get_header() ?>

	
 	<div id="outer">
	
		<?php 
		require_once("../navigation.php");
		?>
	
	<div id="htmlLayer">
	<div id="container">	
		<div id="mainContent">

<?php the_post() ?>

			

			
				
				<div class="entry-meta">

					<span class="entry-date"><abbr class="published" title="<?php the_time('Y-m-d\TH:i:sO') ?>"><?php unset($previousday); printf( __( '%1$s &#8211; %2$s', 'sandbox' ), the_date( '', '', '', false ), get_the_time() ) ?></abbr></span>

				</div>
				
				<?php $flashTitle = get_the_title();?>


				<div id="titleLayer">
					<h2><?php echo get_the_title(); ?></h2>
				</div><!-- titleLayer -->
				<div id="most_recent_content">
				
<?php the_content() ?>


				
				<div class="entry-meta">
				</div>
				
				
			</div><!-- most_recent_content -->

			

<?php comments_template() ?>

		</div><!-- #content -->
		
	</div><!-- #container -->
	
	</div><!-- #htmlLayer -->
	<?php get_footer(); ?>
	</div><!-- #outer -->
	
	</body>
	</html>


