<?php
# Using HTTP_HOST

$domain = $_SERVER['HTTP_HOST'];
$rootpath = "http://{$domain}/";
$url = $_SERVER['REQUEST_URI'];
$pos = strrpos($url, "stage");
if ($pos == true) {
	$rootpath = $rootpath."stage/trewgear2011/";
}

?>

<style type="text/css">

	.socialIcon {
		float: left;
		padding: 10px 10px 0px 0px;
	}
	
</style>

<div id="footer">
	<div id="footerContent">
		<div id="footer_address">
			<b>Trew Gear LLC</b><br>
			Mailing Address:<br>
			1767 12th St. #169 Hood River, OR 97031<br>
			*call 541-241-MTNS for our office location<br>
			t. 541-241-6867<br>
			e. <a href="mailto:info@trewgear.com">info@trewgear.com</a><br><br>
			©2012 Copyright, Trew Gear LLC.
		</div>
		<div id="footer_nav">
			<b><a href="<?php echo $rootpath ?>productwall.php?cID=outerwear">PRODUCTS</a></b><br>
			<a href="<?php echo $rootpath ?>productwall.php?cID=jacket">Jackets</a> / <a href="<?php echo $rootpath ?>productwall.php?cID=pant">Pants</a> / <a href="<?php echo $rootpath ?>productwall.php?cID=swag">Swag</a><br>
			<a href="http://www.shopatron.com/products/category/1771.0.1.1.80549.0.0.0.0">Jackets / Pants / Swag / 2010 Collection</a><br>
			<b><a href="<?php echo $rootpath ?>mission.php">ABOUT US</a></b><br>
			<b><a href="<?php echo $rootpath ?>blog">TOUR</a></b><br>
			<b><a href="mailto:info@trewgear.com">CONTACT</a></b><br>
			<div class="socialIcon"><a href="http://twitter.com/trew_gear"><img src="<?php echo $rootpath ?>resources/images/footer/twitter.gif" border=0></a></div>
			<div class="socialIcon"><a href="http://www.facebook.com/TREWGear"><img src="<?php echo $rootpath ?>resources/images/footer/facebook.gif" border=0></a></div>
			<div class="socialIcon"><a href="http://www.onepercentfortheplanet.org"><img src="<?php echo $rootpath ?>resources/images/footer/onepercent.gif" border=0></a></div>
			<div class="clear">&nbsp;</div>
		</div>
		<!-- <form id="newsletter-signup" action="?action=signup" method="post">
		    <fieldset>
		        <label for="signup-email" id="signup-label">SIGN UP FOR NEWS AND ALL THINGS TREW!</label><br>
		        <input type="text" name="signup-email" id="signup-email" value="ENTER YOUR EMAIL ADDRESS" onfocus="if(this.value == 'ENTER YOUR EMAIL ADDRESS') { this.value = ''; }"/>
		        <input type="submit" id="signup-button" value="JOIN US!" />
		    </fieldset>
		</form>
		<p id="signup-response"></p> -->
		
		<!-- Begin MailChimp Signup Form -->
		<link href="http://cdn-images.mailchimp.com/embedcode/slim-081711.css" rel="stylesheet" type="text/css">
		<style type="text/css">
			#mc_embed_signup{background:#000; float:right; font:9px Helvetica,Arial,sans-serif; }
		</style>
		<div id="mc_embed_signup">
		<form action="http://trewgear.us4.list-manage.com/subscribe/post?u=2d18e9aed6fe74bdfb3e09bc7&amp;id=993cb1dae7" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank">
			<label for="mce-EMAIL">SIGN UP FOR NEWS AND ALL THINGS TREW!</label>
			<input type="email" value="" name="EMAIL" class="email" id="mce-EMAIL" placeholder="ENTER YOUR EMAIL ADDRESS" required>
			<input type="submit" value="JOIN US!" name="subscribe" id="mc-embedded-subscribe" class="button">
		</form>
		</div>

		<!--End mc_embed_signup-->
		
	</div>
</div>
